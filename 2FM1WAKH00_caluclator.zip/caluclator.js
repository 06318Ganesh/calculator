document.addEventListener('DOMContentLoaded', function() {
    const display = document.getElementById('display');
    let currentInput = '0';
    let firstOperand = null;
    let operator = null;
    let waitingForSecondOperand = false;

    function updateDisplay() {
        display.textContent = currentInput;
    }

    function clear() {
        currentInput = '0';
        firstOperand = null;
        operator = null;
        waitingForSecondOperand = false;
        updateDisplay();
    }

    function handleNumberClick(number) {
        if (waitingForSecondOperand) {
            currentInput = number.toString();
            waitingForSecondOperand = false;
        } else {
            currentInput = currentInput === '0' ? number.toString() : currentInput + number.toString();
        }
        updateDisplay();
    }

    function handleOperatorClick(nextOperator) {
        const inputValue = parseFloat(currentInput);

        if (firstOperand === null) {
            firstOperand = inputValue;
        } else if (operator) {
            const result = calculate(firstOperand, inputValue, operator);
            currentInput = result.toString();
            firstOperand = result;
        }

        operator = nextOperator;
        waitingForSecondOperand = true;
        updateDisplay();
    }

    function calculate(firstOperand, secondOperand, operator) {
        switch (operator) {
            case '+':
                return firstOperand + secondOperand;
            case '-':
                return firstOperand - secondOperand;
            case '*':
                return firstOperand * secondOperand;
            case '/':
                return firstOperand / secondOperand;
            default:
                return secondOperand;
        }
    }

    document.getElementById('clear').addEventListener('click', clear);

    document.querySelectorAll('.number').forEach(button => {
        button.addEventListener('click', () => handleNumberClick(button.textContent));
    });

    document.querySelectorAll('.operator').forEach(button => {
        button.addEventListener('click', () => handleOperatorClick(button.textContent));
    });

    document.getElementById('equals').addEventListener('click', () => {
        if (operator !== null) {
            const inputValue = parseFloat(currentInput);
            currentInput = calculate(firstOperand, inputValue, operator).toString();
            operator = null;
            firstOperand = null;
            waitingForSecondOperand = false;
            updateDisplay();
        }
    });
});